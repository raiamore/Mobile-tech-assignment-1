package com.example.myfirstapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

// Firebase imports
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

// Added for reading data
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // 🔹 Receive message from StartActivity
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String msg = extras.getString("message");
            TextView textView = findViewById(R.id.textViewOutput);
            textView.setText(msg);
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main),
                (View v, WindowInsetsCompat insets) -> {
                    Insets systemBars =
                            insets.getInsets(WindowInsetsCompat.Type.systemBars());
                    v.setPadding(systemBars.left,
                            systemBars.top,
                            systemBars.right,
                            systemBars.bottom);
                    return insets;
                });
    }

    // 🔹 This is the method linked to android:onClick="displayMessage"
    public void displayMessage(View view) {

        TextView textView = findViewById(R.id.textViewOutput);
        EditText editText = findViewById(R.id.editTextInput);

        String message = editText.getText().toString();

        if (message.isEmpty()) {
            textView.setText("Please enter a message");
        } else {
            textView.setText(message);
        }

        // ✅ Toast message
        Toast.makeText(this, "OK button clicked.", Toast.LENGTH_LONG).show();

        // 🔹 WRITE DATA (push - multiple values)
        String inputText = editText.getText().toString();
        DatabaseReference dbref = FirebaseDatabase.getInstance().getReference("UI and Events");
        String childname = dbref.push().getKey();
        dbref.child(childname).setValue(inputText);

        // 🔹 READ MULTIPLE VALUES
        DatabaseReference readRef = FirebaseDatabase.getInstance()
                .getReference("UI and Events");

        readRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {

                StringBuilder builder = new StringBuilder();

                for (DataSnapshot child : snapshot.getChildren()) {
                    String value = child.getValue(String.class);
                    builder.append(value).append("\n");
                }

                textView.setText(builder.toString());
            }

            @Override
            public void onCancelled(DatabaseError error) {
                textView.setText("Error: " + error.getMessage());
            }
        });
    }
}