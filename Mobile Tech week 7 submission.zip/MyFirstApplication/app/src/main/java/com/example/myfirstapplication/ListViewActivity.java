package com.example.myfirstapplication;

import android.content.ContentUris;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class ListViewActivity extends AppCompatActivity {

    String reader = "No reader";
    String result = "No result";
    String filename;
    Uri uri = Uri.EMPTY;

    List<MLKitResult> mlKitResults = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_view);

        // ✅ Receive data from MLKitActivity
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            reader = extras.getString("reader");
            result = extras.getString("result");
            filename = extras.getString("filename");
        }

        // ✅ Load image from gallery
        try {
            uri = loadImageFromGallery(filename + ".png");
        } catch (Exception e) {
            e.printStackTrace();
        }

        // ✅ Add item to list
        mlKitResults.add(new MLKitResult(reader, result, uri));

        // ✅ Setup ListView
        ListView listView = findViewById(R.id.listView);
        MLKitAdapter adapter =
                new MLKitAdapter(this, R.layout.list_item, mlKitResults);
        listView.setAdapter(adapter);

        // ✅ Click item → go back to MLKitActivity
        listView.setOnItemClickListener((parent, view, position, id) -> {

            MLKitResult item = mlKitResults.get(position);

            android.content.Intent intent =
                    new android.content.Intent(this, MLKitActivity.class);

            intent.putExtra("result", item.getResult());
            intent.putExtra("uri", item.getImageUri().toString());

            startActivity(intent);
        });
    }

    // 🔍 Load image using filename
    private Uri loadImageFromGallery(String filename) {

        Uri uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;

        String[] projection = {
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DISPLAY_NAME
        };

        String selection = MediaStore.Images.Media.DISPLAY_NAME + "=?";
        String[] selectionArgs = {filename};

        Cursor cursor = getContentResolver().query(
                uri, projection, selection, selectionArgs, null
        );

        if (cursor != null && cursor.moveToFirst()) {

            int idColumn = cursor.getColumnIndexOrThrow(
                    MediaStore.Images.Media._ID);

            long imageId = cursor.getLong(idColumn);

            cursor.close();

            return ContentUris.withAppendedId(uri, imageId);
        }

        return null;
    }
}