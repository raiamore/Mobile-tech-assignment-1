package com.example.myfirstapplication;

import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import java.io.OutputStream;

public class MLKitActivity extends AppCompatActivity {

    private Uri imageFileUri;
    private ImageView imageView;
    private TextView textViewOutput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_mlkit);

        imageView = findViewById(R.id.imageViewMLKit);
        textViewOutput = findViewById(R.id.textViewMLKit);

        // Receive data when coming back from ListView
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String result = extras.getString("result");
            String uriString = extras.getString("uri");

            if (result != null) {
                textViewOutput.setText(result);
            }

            if (uriString != null) {
                Uri uri = Uri.parse(uriString);
                imageView.setImageURI(uri);
                imageFileUri = uri;
            }
        }
    }

    //  CAMERA BUTTON
    public void openCamera(View view) {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        imageFileUri = getContentResolver().insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                new ContentValues()
        );

        intent.putExtra(MediaStore.EXTRA_OUTPUT, imageFileUri);
        activityResultLauncher.launch(intent);
    }

    //  GALLERY BUTTON
    public void loadImage(View view) {

        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");

        activityResultLauncher.launch(intent);
    }

    //  RESULT HANDLER
    ActivityResultLauncher<Intent> activityResultLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if (result.getResultCode() == RESULT_OK) {

                            // If image from gallery
                            if (result.getData() != null &&
                                    result.getData().getData() != null) {
                                imageFileUri = result.getData().getData();
                            }

                            if (imageFileUri != null) {
                                imageView.setImageURI(imageFileUri);
                                textViewOutput.setText("");

                                try {
                                    com.google.mlkit.vision.common.InputImage image =
                                            com.google.mlkit.vision.common.InputImage
                                                    .fromFilePath(this, imageFileUri);

                                    processBarcode(image);

                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                    });

    //  BARCODE SCANNER
    private void processBarcode(com.google.mlkit.vision.common.InputImage image) {

        com.google.mlkit.vision.barcode.BarcodeScanner scanner =
                com.google.mlkit.vision.barcode.BarcodeScanning.getClient();

        scanner.process(image)
                .addOnSuccessListener(barcodes -> {

                    if (barcodes.size() == 0) {
                        textViewOutput.setText("No barcode found");
                        return;
                    }

                    textViewOutput.setText("Detected:\n");

                    for (com.google.mlkit.vision.barcode.common.Barcode barcode : barcodes) {
                        String value = barcode.getRawValue();
                        textViewOutput.append(value + "\n");
                    }

                })
                .addOnFailureListener(e -> {
                    textViewOutput.setText("Failed to scan");
                });
    }

    //  OPEN LIST VIEW BUTTON
    public void openListView(View view) {

        if (imageFileUri == null) {
            textViewOutput.setText("No image selected");
            return;
        }

        Bitmap bitmap = getBitmapFromUri(imageFileUri);

        if (bitmap == null) {
            textViewOutput.setText("Error loading image");
            return;
        }

        String fileName = String.valueOf(System.currentTimeMillis());

        saveImageToGallery(bitmap, fileName);

        Intent intent = new Intent(this, ListViewActivity.class);
        intent.putExtra("reader", "Barcode Reader");
        intent.putExtra("result", textViewOutput.getText().toString());
        intent.putExtra("filename", fileName);

        startActivity(intent);
    }

    //  Convert URI → Bitmap
    private Bitmap getBitmapFromUri(Uri uri) {
        try {
            ImageDecoder.Source source =
                    ImageDecoder.createSource(getContentResolver(), uri);
            return ImageDecoder.decodeBitmap(source);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    //  Save image to gallery
    private void saveImageToGallery(Bitmap bitmap, String fileName) {
        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");

            Uri uri = getContentResolver().insert(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
            );

            if (uri != null) {
                OutputStream outputStream =
                        getContentResolver().openOutputStream(uri);

                bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream);

                if (outputStream != null) {
                    outputStream.close();
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}