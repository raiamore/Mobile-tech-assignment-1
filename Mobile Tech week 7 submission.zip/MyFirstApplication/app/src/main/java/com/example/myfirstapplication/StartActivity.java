package com.example.myfirstapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View; //  IMPORTANT import
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class StartActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_start);

        // 🔹 Runtime onClick listener
        Button button = findViewById(R.id.buttonUIEvent);

        button.setOnClickListener(v -> {
            Intent intent = new Intent(StartActivity.this, MainActivity.class);

            //  send data to MainActivity
            intent.putExtra("message", "Hello World!");

            startActivity(intent);
        });

        Button buttonLocationServices = findViewById(R.id.buttonLocationServices);

        buttonLocationServices.setOnClickListener(v -> {
            Intent intent = new Intent(StartActivity.this, LocationServicesActivity.class);
            startActivity(intent);
        });

        // 🔹 Edge-to-edge window handling
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left,
                    systemBars.top,
                    systemBars.right,
                    systemBars.bottom);
            return insets;
        });
    }

    // new addition for this week
    public void openMLKitActivity(View view) {
        Intent intent = new Intent(StartActivity.this, MLKitActivity.class);
        startActivity(intent);
    }
}