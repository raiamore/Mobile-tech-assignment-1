package com.example.myfirstapplication;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;

import java.util.List;
import java.util.Locale;

public class LocationServicesActivity extends AppCompatActivity {

    private FusedLocationProviderClient fusedLocationClient;
    private TextView textViewLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_location_services);

        textViewLocation = findViewById(R.id.textViewLocation);
        Button buttonGetLocation = findViewById(R.id.buttonGetLocation);

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        buttonGetLocation.setOnClickListener(v -> getLocation());
    }

    private void getLocation() {

        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    100);
            return;
        }

        // ✅ UPDATED: get REAL-TIME location instead of cached
        fusedLocationClient.getCurrentLocation(
                Priority.PRIORITY_HIGH_ACCURACY,
                null
        ).addOnSuccessListener(location -> {

            if (location != null) {
                double lat = location.getLatitude();
                double lon = location.getLongitude();

                String address = getAddress(lat, lon);

                textViewLocation.setText(
                        "Latitude: " + lat +
                                "\nLongitude: " + lon +
                                "\nAddress: " + address
                );

            } else {
                textViewLocation.setText("Location not available");
            }
        });
    }

    private String getAddress(double lat, double lon) {
        try {
            Geocoder geocoder = new Geocoder(this, Locale.getDefault());
            List<Address> addresses = geocoder.getFromLocation(lat, lon, 1);

            if (addresses != null && !addresses.isEmpty()) {
                return addresses.get(0).getAddressLine(0);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return "Address not found";
    }
}