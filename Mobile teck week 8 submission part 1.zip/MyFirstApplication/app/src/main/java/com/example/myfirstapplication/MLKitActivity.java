package com.example.myfirstapplication;

import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class MLKitActivity extends AppCompatActivity {

    private Uri imageFileUri;
    private ImageView imageView;
    private TextView textViewOutput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_mlkit);

        imageView = findViewById(R.id.imageViewMLKit);
        textViewOutput = findViewById(R.id.textViewMLKit);
    }

    // ✅ CAMERA BUTTON
    public void openCamera(View view) {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        imageFileUri = getContentResolver().insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                new ContentValues()
        );

        intent.putExtra(MediaStore.EXTRA_OUTPUT, imageFileUri);

        activityResultLauncher.launch(intent);
    }

    // ✅ GALLERY BUTTON
    public void loadImage(View view) {
        Intent intent = new Intent(Intent.ACTION_PICK,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

        activityResultLauncher.launch(intent);
    }

    // ✅ RESULT HANDLER + ML KIT INTEGRATION
    ActivityResultLauncher<Intent> activityResultLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if (result.getResultCode() == RESULT_OK) {

                            // If image from gallery
                            if (result.getData() != null &&
                                    result.getData().getData() != null) {
                                imageFileUri = result.getData().getData();
                            }

                            // Show image
                            if (imageFileUri != null) {
                                imageView.setImageURI(imageFileUri);

                                textViewOutput.setText("");

                                try {
                                    com.google.mlkit.vision.common.InputImage image =
                                            com.google.mlkit.vision.common.InputImage
                                                    .fromFilePath(this, imageFileUri);

                                    processBarcode(image);

                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                    });

    // ✅ BARCODE / QR SCANNER
    private void processBarcode(com.google.mlkit.vision.common.InputImage image) {

        com.google.mlkit.vision.barcode.BarcodeScanner scanner =
                com.google.mlkit.vision.barcode.BarcodeScanning.getClient();

        scanner.process(image)
                .addOnSuccessListener(barcodes -> {

                    if (barcodes.size() == 0) {
                        textViewOutput.setText("No barcode found");
                        return;
                    }

                    textViewOutput.setText("Detected:\n");

                    for (com.google.mlkit.vision.barcode.common.Barcode barcode : barcodes) {
                        String value = barcode.getRawValue();
                        textViewOutput.append(value + "\n");
                    }

                })
                .addOnFailureListener(e -> {
                    textViewOutput.setText("Failed to scan");
                });
    }
}