package com.example.myfirstapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class SQLiteActivity extends AppCompatActivity {

    Spinner spinner;
    ArrayList<String> items = new ArrayList<>();
    ArrayAdapter<String> adapter;
    MyDbHelper dbHelper;
    String selectedItem = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sqlite);

        dbHelper = new MyDbHelper(SQLiteActivity.this, "MobileTechResults", null, 1);

        spinner = findViewById(R.id.spinner);

        items = dbHelper.readAll();
        items.add(0, "Select an item");

        adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, items);

        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedItem = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    // SAVE
    public void save(View view) {
        EditText editTextName = findViewById(R.id.editTextName);
        EditText editTextMark = findViewById(R.id.editTextMark);

        String name = editTextName.getText().toString();
        String mark = editTextMark.getText().toString();

        if (name.isEmpty() || mark.isEmpty()) {
            Toast.makeText(this, "Enter name and mark", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            Double.parseDouble(mark);
            dbHelper.create(name, mark);
            Toast.makeText(this, "Saved!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Invalid mark", Toast.LENGTH_SHORT).show();
        }

        refreshSpinner();
    }

    // DELETE
    public void delete(View view) {
        if (selectedItem.equals("Select an item")) return;

        int from = selectedItem.indexOf(':') + 2;
        int to = selectedItem.indexOf(',');

        String name = selectedItem.substring(from, to);

        dbHelper.delete(name);
        refreshSpinner();
    }

    // UPDATE
    public void update(View view) {
        if (selectedItem.equals("Select an item")) return;

        EditText editTextNewMark = findViewById(R.id.editTextNewMark);

        int from = selectedItem.indexOf(':') + 2;
        int to = selectedItem.indexOf(',');

        String name = selectedItem.substring(from, to);
        String newMark = editTextNewMark.getText().toString();

        try {
            Double.parseDouble(newMark);
            dbHelper.update(name, newMark);
        } catch (Exception e) {
            Toast.makeText(this, "Invalid mark", Toast.LENGTH_SHORT).show();
        }

        refreshSpinner();
    }

    // REFRESH
    private void refreshSpinner() {
        items = dbHelper.readAll();
        items.add(0, "Select an item");

        adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, items);

        spinner.setAdapter(adapter);
    }
}